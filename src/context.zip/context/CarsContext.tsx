import React, { createContext, useState, useEffect, ReactNode } from "react";
import axios from "axios";

interface Car {
  id: string;
  plate: string;
  manufacture: string;
  model: string;
  image: string | null;
  rentPerDay: number;
  capacity: number;
  description: string;
  availableAt: Date | null;
  transmission: string;
  available: boolean;
  type: string;
  year: number;
  options: string[];
  specs: string[];
}

interface CarsContextType {
  cars: Car[];
}

const CarsContext = createContext<CarsContextType | undefined>(undefined);

const CarsProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [cars, setCars] = useState<Car[]>([]);

  useEffect(() => {
    axios
      .get("http://localhost:3030/cars", {
        headers: localStorage.getItem("tokenBinar")
          ? {
              Authorization: `Bearer ${localStorage.getItem("tokenBinar")}`,
            }
          : {},
      })
      .then((response) => {
        const activeCars = response.data.data.filter(
          (car: Car) => car.available === true
        );
        setCars(activeCars);
      })
      .catch((error) => {
        console.error(error);
      });
  }, []);

  return (
    <CarsContext.Provider
      value={{
        cars,
      }}
    >
      {children}
    </CarsContext.Provider>
  );
};

export { CarsContext, CarsProvider };
